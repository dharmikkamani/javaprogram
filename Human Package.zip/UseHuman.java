import Human.Developer;

class UseHuman
{
	public static void main(String args[])
	{
		Developer d = new Developer();
		d.hbaccess();
		d.ud();
		d.check();
		
	}
}