package Human;
import java.util.Scanner;

class Hobby
{
	
	protected void hobby()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Your Hobby \n");
		String h = sc.nextLine();
		System.out.println("Hobby is : " + h);
	}
}
class User extends Hobby
{
	Scanner ud = new Scanner(System.in);
		
	String name;
	String address;
	String cno;
	String qua;
	
	private void Userdata()
	{
		System.out.println("Enter Your Name \n");
		name = ud.nextLine();
		System.out.println("Enter Your Address \n");
		address = ud.nextLine();
		System.out.println("Enter Your Contact Number \n");
		cno = ud.nextLine();
		System.out.println("Enter Your Qualification \n");
		qua = ud.nextLine();
	}
	
	
	
	//This method is used to show data
	protected void stddata()
	{
		System.out.println("Student Details");
		System.out.println("Name : " + name);
		System.out.println("Addredd : " + address);
		System.out.println("Contact : " + cno);
		System.out.println("Qualification : " + qua);
	}
	
	//It Shows Data Of Developer Class
	protected void showddata()
	{
		System.out.println("Developer Details");
		System.out.println("Name : " + name);
		System.out.println("Addredd : " + address);
		System.out.println("Contact : " + cno);
		System.out.println("Qualification : " + qua);
	}
	
	//This Method is use for call hobby
	public void hbaccess()
	{
		hobby();
	}
	
	//This Method is Used To Call Private Method
	public void ud()
	{
		Userdata();
	}
}

class Student extends User
{
	protected void showdata()
	{
		stddata();
	}
	
	protected void showd()
	{
		showddata();
	}
}

public class Developer extends Student
{
	
	public void check()
	{	
		System.out.println("What is Your Proffession \n Press 1 For Student \n Press 2 For Developer");
		int pro = ud.nextInt();
		if(pro == 1)
		{
			//Below Method Calls Student Show Data Method
			showdata();
		}
		else if(pro == 2)
		{
			//Below Method Calls Developer Show Data Method
			showd();
		}
	}
	
}