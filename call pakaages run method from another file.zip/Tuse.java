import threduse.Tu;

class Tuse
{
	public static void main(String args[])
	{
		Tu t1 = new Tu();
		t1.start();
		t1.perform(50,50);
		t1.sub(10,5);
	}
}