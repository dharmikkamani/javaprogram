package threduse;

public class Tu extends Thread
{
	
	Thread t;
	public int ans;
	public Tu()
	{
		if(t == null)
		{
			t = new Thread();
			t.start();
		}
	}
	
	public void perform(int a, int b)
	{
		System.out.println("This method is Performing Sum");
		ans = a + b;
		System.out.println("Sum is" + ans);
		
	}
	
		public void sub(int a, int b)
	{
		System.out.println("This method is Performing Sum");
		ans = a - b;
		System.out.println("Substraction is" + ans);
		
	}
	
	public void run()
	{
		System.out.println("Thread is Running");
		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println("Thread is Running Again");
	}
}